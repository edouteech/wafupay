<?php

return [
    'phone_valid_number' => "Le numéro de téléphone : doit être au format +CodeDyPaysNumeroDeTelephone et contenir 8 ou 10 chiffres après l'indicatif du pays(pays de l'UEMOA).",
    'valid_receiver_account' => 'Le compte du destinataire existe mais n\'est pas actif',
    'valid_sender_account' => 'Votre compte n\'est pas activé, merci de le vérifier avant toute transaction',
    'valid_provider_name' => 'Le nom de l\'operateur monetaire selectionné n\'existe pas ou n\'est pas supporté pour le moment, veuillez choisir entre :providers',
];
