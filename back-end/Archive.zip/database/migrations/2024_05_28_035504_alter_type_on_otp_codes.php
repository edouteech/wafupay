<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        DB::statement("ALTER TABLE otp_codes MODIFY COLUMN type ENUM('2fa', 'reset_password', 'email_verification') NOT NULL");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::statement("ALTER TABLE otp_codes MODIFY COLUMN type ENUM('2fa', 'reset_password') NOT NULL");
    }
};
